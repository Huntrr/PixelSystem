        <!-- START FOOTER -->
            <div id="footer">
                <p>Copyright &#169; 2013-<?php echo date('Y'); ?> Hunter Lightman</p>
            </div>
        <!-- END FOOTER -->
        <?php wp_footer() ?>
        </div>
    </body>
</html>
