<!-- 

Oh. I see. You're THAT kind of person. Well, fine then. Here, I left this just for you:
http://hunterlightman.com/blankpage.html

-->

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>" />

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

        <!-- For mobile devices -->
        <meta name="viewport" content="width=600, user-scalable=no, target-densitydpi=high-dpi" />
        <meta http-equiv="Content-Type" content="application/vnd.wap.xhtml+xml; charset=utf-8" />
        <meta name="HandheldFriendly" content="true" />
        <meta name="apple-mobile-web-app-capable" content="yes" /> 
        <!-- End of mobile meta -->

        <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>">
        
        <title><?php bloginfo('name'); ?></title>
        <meta name="description" content="<?php bloginfo( 'description' ); ?>">

        <?php wp_head(); ?>
    </head>

    <body>
        
        <!-- START "CONTENT" -->
        <?php
            // Get the ID of a given category
            $category_id = get_cat_ID( 'Blog' );
            // Get the URL of this category
            $blog = get_category_link( $category_id );
            
            // Get the ID of a given category
            $category_id = get_cat_ID( 'Code' );
            // Get the URL of this category
            $code = get_category_link( $category_id );
            
            // Get the ID of a given category
            $category_id = get_cat_ID( 'Write' );
            // Get the URL of this category
            $write = get_category_link( $category_id );
            
            // Get the ID of a given category
            $category_id = get_cat_ID( 'Build' );
            // Get the URL of this category
            $build = get_category_link( $category_id );

            $about = "//hunterlightman.com/about/";
        ?>

        <div id="background" class="home-background">
            <div id="distant"></div>
            <div id="stars"></div>

            <div class="sun home-sun"></div>
        </div>

        <div id="home-header">
            <h1>HUNTER LIGHTMAN</h1>
            <h4>Why not click one?</h4>
        </div>

        <div id="home-menu">
            <div class="home-item" id="home-earth">
                <div class="planet">
                    <img class="earth" src="<?php bloginfo('template_directory') ?>/img/celestial/earth.png">
                    <img class="moon" src="<?php bloginfo('template_directory') ?>/img/celestial/moon.png">
                </div>
                <a class="menu-link" href="<?php echo esc_url( $blog ); ?>">&#62; Blog</a>
            </div>

            <div class="home-item" id="home-red">
                <div class="planet">
                    <img class="red" src="<?php bloginfo('template_directory') ?>/img/celestial/red.png">
                </div>
                <a class="menu-link" href="<?php echo esc_url( $code ); ?>">&#62; Code</a>
            </div>

            <div class="home-item" id="home-gas">
                <div class="planet">
                    <img class="gas" src="<?php bloginfo('template_directory') ?>/img/celestial/gas.png">
                </div>
                <a class="menu-link" href="<?php echo esc_url( $write ); ?>">&#62; Write</a>
            </div>

            <div class="home-item" id="home-ring">
                <a class="menu-link" href="<?php echo esc_url( $build ); ?>">Build &#60;</a>
                <div class="planet">
                    <img class="ring" src="<?php bloginfo('template_directory') ?>/img/celestial/ringed.png">
                </div>
            </div>

            <div class="home-item" id="home-cold">
                <a class="menu-link" href="<?php echo $about ?>">About &#60;</a>
                <div class="planet">
                    <img class="cold" src="<?php bloginfo('template_directory') ?>/img/celestial/cold.png">
                </div>
            </div>
        </div>


        <div id="home-footer">
            <p class="quote">"I had better never see a book, than to be warped by its attraction clean out of my own orbit, and made a satellite instead of a system"</p>
            <p class="quote-author">— Ralph Waldo Emerson, <span class="italic">The American Scholar</span>, 1837</p>
        </div>

        <?php wp_footer() ?>
    </body>
</html>
